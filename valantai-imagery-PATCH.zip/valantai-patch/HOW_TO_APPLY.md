# Valantai — Imagery patch

This ZIP contains the files that add the architectural SVG imagery system
to your existing v-new GitHub repo.

## What's in here

```
components/imagery/DocumentaryPlaceholder.tsx  ← NEW file: 8 SVG compositions
components/imagery/ImageSlot.tsx               ← NEW file: image slot component
lib/imagery.ts                                 ← NEW file: image registry
app_page.tsx                                   ← REPLACE app/page.tsx
app_platform_risk_page.tsx                     ← GUIDANCE for platform/risk
HOW_TO_APPLY.md                                ← this file
```

## Steps

### Step 1 — Copy the 3 new files
Copy these directly into your repo (create the folders if needed):
```
components/imagery/DocumentaryPlaceholder.tsx
components/imagery/ImageSlot.tsx
lib/imagery.ts
```

### Step 2 — Replace app/page.tsx
Replace your existing `app/page.tsx` with `app_page.tsx` from this ZIP.

This removes the "Image reserved — commissioned photography" text and
replaces it with the `<ImageSlot>` component.

### Step 3 — Update app/platform/risk/page.tsx
Open your existing `app/platform/risk/page.tsx` and make two changes:

**Add the import** (at the top, with other imports):
```tsx
import { ImageSlot } from '@/components/imagery/ImageSlot';
```

**Add the hero image** (immediately before `<PageHero ...>`):
```tsx
{/* Hero image — first visible element */}
<ImageSlot context="risk_hero" aspect="21/8" priority />
```

**Add a secondary band** (somewhere mid-page, e.g. before or after the
domains table section):
```tsx
<div className="px-[var(--margin)] py-[4vh]">
  <ImageSlot context="risk_operations" aspect="32/9" />
</div>
```

### Step 4 — Update solution pages (if you have them)
If you have `app/solutions/[slug]/page.tsx`, add the same pattern:
```tsx
import { ImageSlot } from '@/components/imagery/ImageSlot';

// Before <PageHero>:
<ImageSlot context={SOLUTION_IMAGE_CONTEXT[sol.slug]} aspect="21/8" priority />
```

See `lib/imagery.ts` for all available context keys.

### Step 5 — Push to GitHub
```bash
git add .
git commit -m "feat: add architectural imagery system"
git push
```
Vercel will auto-deploy.

## What you'll see

Each page will show one of 8 architectural SVG compositions:
- **Sphere** — LED computational surface (homepage)
- **Control** — bright operations centre (risk pages)
- **Facade** — parametric stone surface (platform/risk hero)
- **Glass** — glass curtain wall (capital)
- **Atrium** — structural interior (build/counsel)
- **Terminal** — transit hub roof (gtm/commerce)
- **Datacenter** — blue-white server infrastructure (intelligence)
- **Aerial** — city from above (grow/esg)

All compositions are SVGs rendered server-side — no image downloads needed,
no broken images, works immediately on deploy.

## Adding real photography later

When you have real photos, drop them in `public/images/` and un-comment
the `photoUrl` lines in `lib/imagery.ts`. The SVG system switches off
automatically when a `photoUrl` is present.
